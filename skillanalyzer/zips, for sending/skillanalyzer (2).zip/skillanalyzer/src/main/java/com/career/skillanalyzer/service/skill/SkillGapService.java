package com.career.skillanalyzer.service.skill;

import com.career.skillanalyzer.service.ai.GeminiService;
import com.career.skillanalyzer.util.JsonCleaner;
import com.google.gson.Gson;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class SkillGapService {

    private final GeminiService geminiService;

    public SkillGapService(GeminiService geminiService) {
        this.geminiService = geminiService;
    }

    public Map<String, Object> generateSkillGap(
            String role,
            Object cvSkills) {

        String prompt =
                "You are a senior hiring manager and career mentor.\n\n" +
                        "Target Role: " + role + "\n\n" +
                        "Candidate Skills: " + cvSkills + "\n\n" +
                        "Generate a skill gap analysis in RAW JSON only.\n" +
                        "Rules:\n" +
                        "- NO markdown\n" +
                        "- NO ```json\n" +
                        "- NO explanations\n\n" +
                        "JSON fields:\n" +
                        "strongSkills (array)\n" +
                        "weakSkills (array)\n" +
                        "missingSkills (array)\n" +
                        "matchPercentage (number)\n" +
                        "improvementAdvice (string)";

        String aiResponse =
                JsonCleaner.clean(geminiService.generate(prompt));

        return new Gson().fromJson(aiResponse, Map.class);
    }
}
