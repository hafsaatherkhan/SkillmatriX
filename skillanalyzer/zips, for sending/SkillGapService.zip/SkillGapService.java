package com.career.skillanalyzer.service.skill;

import com.career.skillanalyzer.service.ai.GeminiService;
import com.career.skillanalyzer.util.JsonCleaner;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.springframework.stereotype.Service;

import java.lang.reflect.Type;
import java.util.*;

@Service
public class SkillGapService {

    private final GeminiService geminiService;
    private final Gson gson = new Gson();

    public SkillGapService(GeminiService geminiService) {
        this.geminiService = geminiService;
    }

    /**
     * Generates a strict skill gap analysis
     */
    public Map<String, Object> generateSkillGap(
            String targetRole,
            Map<String, List<String>> categorizedSkills
    ) {

        // 🔹 Flatten skills (VERY IMPORTANT)
        List<String> allSkills = new ArrayList<>();
        categorizedSkills.values().forEach(allSkills::addAll);

        // Safety: if no skills extracted
        if (allSkills.isEmpty()) {
            return Map.of(
                    "strongSkills", List.of(),
                    "weakSkills", List.of(),
                    "missingSkills", List.of(),
                    "matchPercentage", 0,
                    "improvementAdvice",
                    "No professional skills were detected in the CV. Please add relevant experience, education, or certifications."
            );
        }

        String prompt =
                "You are a STRICT skill gap analysis engine.\n\n" +
                        "Target Role: " + targetRole + "\n\n" +
                        "Candidate Skills (ONLY these skills exist):\n" +
                        allSkills + "\n\n" +
                        "Rules:\n" +
                        "- Do NOT invent or assume any skills\n" +
                        "- Only evaluate based on the provided skills\n" +
                        "- If a required skill is missing, list it under missingSkills\n" +
                        "- Weak skills = partially relevant or basic-level skills\n" +
                        "- Strong skills = clearly relevant and sufficient\n\n" +
                        "Return ONLY raw JSON with this exact structure:\n\n" +
                        "{\n" +
                        "  \"strongSkills\": [],\n" +
                        "  \"weakSkills\": [],\n" +
                        "  \"missingSkills\": [],\n" +
                        "  \"matchPercentage\": 0,\n" +
                        "  \"improvementAdvice\": \"\"\n" +
                        "}";

        String aiResponse = JsonCleaner.clean(geminiService.generate(prompt));

        Type responseType = new TypeToken<Map<String, Object>>() {}.getType();
        return gson.fromJson(aiResponse, responseType);
    }
}



//package com.career.skillanalyzer.service.skill;
//
//import com.career.skillanalyzer.service.ai.GeminiService;
//import com.career.skillanalyzer.util.JsonCleaner;
//import com.google.gson.Gson;
//import org.springframework.stereotype.Service;
//
//import java.util.Map;
//
//@Service
//public class SkillGapService {
//
//    private final GeminiService geminiService;
//
//    public SkillGapService(GeminiService geminiService) {
//        this.geminiService = geminiService;
//    }
//
//    public Map<String, Object> generateSkillGap(
//            String role,
//            Object cvSkills) {
//
//        String prompt =
//                "You are a senior hiring manager and career mentor.\n\n" +
//                        "Target Role: " + role + "\n\n" +
//                        "Candidate Skills: " + cvSkills + "\n\n" +
//                        "Generate a skill gap analysis in RAW JSON only.\n" +
//                        "Rules:\n" +
//                        "- NO markdown\n" +
//                        "- NO ```json\n" +
//                        "- NO explanations\n\n" +
//                        "JSON fields:\n" +
//                        "strongSkills (array)\n" +
//                        "weakSkills (array)\n" +
//                        "missingSkills (array)\n" +
//                        "matchPercentage (number)\n" +
//                        "improvementAdvice (string)";
//
//        String aiResponse =
//                JsonCleaner.clean(geminiService.generate(prompt));
//
//        return new Gson().fromJson(aiResponse, Map.class);
//    }
//}
