package com.career.skillanalyzer.Controller;

import com.career.skillanalyzer.service.cv.TextService;
import com.career.skillanalyzer.service.skill.SkillExtractionService;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/resume")
public class ResumeController {

    private final TextService resumeTextService;
    private final SkillExtractionService skillExtractionService;

    public ResumeController(
            TextService resumeTextService,
            SkillExtractionService skillExtractionService) {

        this.resumeTextService = resumeTextService;
        this.skillExtractionService = skillExtractionService;
    }

    @PostMapping("/skill_gap")
    public Map<String, Object> analyzeResume(
            @RequestParam("file") MultipartFile file) {

        Map<String, Object> response = new HashMap<>();

        try {
            String resumeText;
            String filename = file.getOriginalFilename();

            if (filename != null && filename.endsWith(".pdf")) {
                resumeText = resumeTextService.extractText(file);
            }
            else if (filename != null && filename.endsWith(".docx")) {
                XWPFDocument document =
                        new XWPFDocument(file.getInputStream());
                resumeText = resumeTextService.extractText(document);
            }
            else {
                throw new RuntimeException("Unsupported file type");
            }

            List<String> cvSkills =
                    skillExtractionService.extractSkills(resumeText);

            response.put("cvSkills", cvSkills);

        } catch (Exception e) {
            response.put("error", e.getMessage());
        }

        return response;
    }
}
