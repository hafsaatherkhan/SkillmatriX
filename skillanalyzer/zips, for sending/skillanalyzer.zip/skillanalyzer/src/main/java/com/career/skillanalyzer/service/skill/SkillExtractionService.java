package com.career.skillanalyzer.service.skill;

import com.career.skillanalyzer.service.ai.GeminiService;
import com.career.skillanalyzer.util.JsonArrayParser;
import com.career.skillanalyzer.util.JsonCleaner;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SkillExtractionService {

    private final GeminiService geminiService;

    public SkillExtractionService(GeminiService geminiService) {
        this.geminiService = geminiService;
    }

    public List<String> extractSkills(String resumeText) {

        String prompt =
                "Extract ONLY technical skills from this resume.\n" +
                        "Return JSON array only.\n\n" +
                        resumeText;

        String aiResponse =
                JsonCleaner.clean(geminiService.generate(prompt));

        return JsonArrayParser.parse(aiResponse);
    }
}
