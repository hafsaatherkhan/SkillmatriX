package com.career.skillanalyzer.service.ai;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;
import org.springframework.stereotype.Service;

@Service
public class GeminiService {

    public String generate(String prompt) {

        Client client = Client.builder()
                .apiKey("AIzaSyBrEUVyHhQTbcglP7_OvwXErF5IJS0-SyU")
                .build();

        GenerateContentResponse response =
                client.models.generateContent(
                        "gemini-2.5-flash",
                        prompt,
                        null);

        return response.text();
    }
}

