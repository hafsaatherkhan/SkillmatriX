package com.career.skillanalyzer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkillanalyzerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkillanalyzerApplication.class, args);
	}

}
