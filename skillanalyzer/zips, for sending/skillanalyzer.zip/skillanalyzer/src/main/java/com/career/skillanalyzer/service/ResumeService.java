//package com.career.skillanalyzer.service;
//
//import com.google.genai.Client;
//import com.google.genai.types.GenerateContentResponse;
//import com.google.gson.JsonObject;
//import com.google.gson.Gson;
//import org.springframework.stereotype.Service;
//
//import java.util.*;
//
//@Service
//public class ResumeService {
//
//    public static String GenerateResponse (String prompt)
//    {
//        Client client = Client.builder().apiKey("AIzaSyBrEUVyHhQTbcglP7_OvwXErF5IJS0-SyU").build();
//
//        GenerateContentResponse response =
//                client.models.generateContent(
//                        "gemini-2.5-flash",
//                        prompt,
//                        null);
//
//        return response.text();
//    }
//
//    // ---------------- EXTRACT CV SKILLS ----------------
//    public List<String> extractCVSkills(String resumeText) {
//
//        String prompt =
//                "Extract ONLY technical skills from this resume.\n" +
//                        "Return JSON array only.\n\n" +
//                        resumeText;
//
//        String aiResponse = cleanAiResponse(GenerateResponse(prompt));
//        return parseJsonArray(aiResponse);
//
//    }
//
//    // ---------------- AI SKILL GAP REPORT ----------------
//    public Map<String, Object> generateSkillGapReport(
//            String role,
//            List<String> cvSkills
//    ) {
//
//        String prompt =
//                "You are a senior hiring manager and career mentor.\n\n" +
//                        "Target Role: " + role + "\n\n" +
//                        "Candidate Skills: " + cvSkills + "\n\n" +
//                        "Generate a skill gap analysis in RAW JSON only.\n" +
//                        "Rules:\n" +
//                        "- NO markdown\n" +
//                        "- NO ```json\n" +
//                        "- NO explanations\n\n" +
//                        "JSON fields:\n" +
//                        "strongSkills (array)\n" +
//                        "weakSkills (array)\n" +
//                        "missingSkills (array)\n" +
//                        "matchPercentage (number)\n" +
//                        "improvementAdvice (string)";
//
//        String aiResponse =
//                cleanAiResponse(GenerateResponse(prompt));
//
//        Gson gson = new Gson();
//        return gson.fromJson(aiResponse, Map.class);
//    }
//
//    // ---------------- JSON ARRAY PARSER ----------------
//    private List<String> parseJsonArray(String text) {
//        try {
//            Gson gson = new Gson();
//            return Arrays.asList(gson.fromJson(text, String[].class));
//        } catch (Exception e) {
//            return new ArrayList<>(); // fail safely
//        }
//    }
//
//
//    private String cleanAiResponse(String text) {
//        if (text == null) return "";
//        return text
//                .replaceAll("```json", "")
//                .replaceAll("```", "")
//                .trim();
//    }
//
//}

